/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package krish.assignment1;

/**
 *
 * @author S300095291
 */
public class KrishAssignment1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int favnumber;
        double decimal;
        boolean boolvalue;
        char symbol;
        String name;
        
        name = "Krish";
        favnumber = 4;
        decimal = 0.1 * 4;
        boolvalue = true;
        symbol = '!';
        System.out.println("My name is " + name + "\nMy favourite number is " + favnumber + "\n10% of the number is " + decimal + "\nIt is " + boolvalue + " that " + symbol + " is an exclamation mark." );

        
        // TODO code application logic here
    }
    
}
